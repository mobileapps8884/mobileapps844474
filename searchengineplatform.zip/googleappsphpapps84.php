<style>

html
{
margin:0px;
padding:0px;
font-family: Varela Round, sans-serif;
font-size:small;
}

body
{
margin:0px;
padding:0px;
}

.googleapps8884
{
background-color:#fafafa;
width:274px;
height:100%;
}

.googleapps1
{
border-style: solid;
border-width: 1px;
padding: 8px;
bottom: 206px;
left: 304px;
border-bottom: none;
width: 804px;
}

.googleapps2
{
border-style: solid;
border-width: 1px;
padding: 8px;
bottom: 104px;
left: 304px;
width: 804px;
border-bottom: none;
}

.googleapps3
{
border-style: solid;
border-width: 1px;
padding: 8px;
bottom: 138px;
left: 304px;
border-bottom: none;
width: 804px;
}

.googleapps4
{
border-style: solid;
border-width: 1px;
padding: 8px;
bottom: 172px;
left: 304px;
width: 804px;
}

.googleapps888841
{
}

.googleapps888842
{
}

.googleapps888843
{
}

.googleapps888884
{
}

.googleapps888888441
{
border-style: solid;
border-width: 1px;
padding: 8px;
bottom: 240px;
left: 304px;
border-bottom: none;
width: 804px;
}

.mobileapps888844
{
position:absolute;
}

.googleappsmobileapps888844
{
position:absolute;
right:12px;
top:12px;
color:#222222;
}

.google88888844
{
}

.google888888884444
{
width:18px!important;
border-radius:0px!important;
background: linear-gradient(to bottom, #058dc7 0%,#058dc7 6px,#e6f4fa 6px,#e6f4fa 100%);
}

@media screen and (min-width: 960px)
{
.google88888844
{
position:absolute;
bottom:0px;
margin:44px;
}
.googleapps88888874
{
padding-left:119.8px;
}
.googleapps888888884444
{
padding-left:372px;
}
.google1
{
padding-right:104px;
}
.google2
{
padding-right:104px;
}
.google3
{
padding-right:104px;
}
.google4
{
padding-right:104px;
}
.google8888447444
{
position:absolute;
left:274px;
bottom:0px;
}
}

@media screen and (max-width: 960px)
{
.googleapps8884
{
width:100%;
height:66px;
}
.googleapps888888441
{
width:100%;
border:none;
padding:0px;
padding-bottom:8px;
}
.googleapps1
{
width:100%;
border:none;
padding:0px;
padding-bottom:8px;
}
.googleapps2
{
width:100%;
border:none;
padding:0px;
padding-bottom:8px;
}
.googleapps3
{
width:100%;
border:none;
padding:0px;
padding-bottom:8px;
}
.googleapps4
{
width:100%;
border:none;
padding:0px;
padding-bottom:8px;
}
.googleapps88888874
{
padding-left:24px;
}
.googleapps888888884444
{
padding-left:12px;
}
.google1
{
padding-right:12px;
}
.google2
{
padding-right:12px;
}
.google3
{
padding-right:12px;
}
.google4
{
padding-right:12px;
}
.googleapps888888884444
{
padding-left:190px;
}
.google8888447444
{
padding:12px;
}
.googleappsmobileapps888844
{
color:#222222;
}
.google888888884444
{
font-size:12px!important;
width:4px!important;
}
.googleappsmobileapps888872
{
margin-left:0px!important;
}
.mobileappsinstallapps8884
{
display:none;
}
}

.googleappsmobileapps888872
{
margin-top:-18px;
margin-left:2px;
}

</style>

<head>
<title></title>
<meta name='description' content=''>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="robots" content="index,nofollow">
<link rel="shortcut icon nofollow" href="http://mobile84.herokuapp.com/googleappslogoapps88888844.png" type="image/x-icon"/>
</head>

<?php

$string_to_encrypt="$_GET[username]";
$password="googleapps84";

$decrypted_string=openssl_decrypt($string_to_encrypt,"AES-128-ECB",$password);

?>

<?php

$string_to_encrypt8884="$_GET[password]";
$password8884="googleapps84";

$decrypted_string8884=openssl_decrypt($string_to_encrypt8884,"AES-128-ECB",$password8884);

?>

<div class="googleapps8884">

<div class="googleapps888411">

<div class="googleapps888422" style="padding:12px;color:#222222;">Hi <div class="usernamegoogleapps84" style="color:#222222;"><?php echo "$decrypted_string"; ?></div></div>

</div>

<div class="google88888844">

<div class="google888844">

<div class="google8888447444">

<div class="googleapps888888441">

<mobileapps84 class="google1">ad name</mobileapps84>

<mobileapps84 class="google1">impressions</mobileapps84>

<mobileapps84 class="google2">clicks</mobileapps84>

<mobileapps84 class="google3">usage</mobileapps84>

</div>

<div class="googleapps888841">

<div class="googleapps1">

<?php

$googlapps8884 = file_get_contents("http://mobile84.herokuapp.com/googleapps84.sh");

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'><div class='installgoogleapps'><div class='installgoogleapps84'><div class='installgoogleapps8432'><div id='googleapps84'><h3>(.*?)<\/h3>/", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

echo "<mobileapps84 class='mobileapps888844'>$google8884</mobileapps84>";

?>

<?php

$file84 = file_get_contents("http://mobile84.herokuapp.com/googleappsmobileinstallapps8884.sh");

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div>/", $file84, $match);

$google8884 = $match[1];

$nooflines = count($google8884);

echo "<mobileapps84 class='googleapps888888884444'>$nooflines</mobileapps84>";

?>

<?php

$googleapps8884 = $nooflines * 0.02;

echo "<mobileapps84 class='googleapps88888874'>\$$googleapps8884</mobileapps84>";

?>

</div>

</div>

<div class="googleapps888842">

<div class="googleapps2">googleapps84</div>

</div>

<div class="googleapps888843">

<div class="googleapps3">googleapps84</div>

</div>

<div class="googleapps888884">

<div class="googleapps4">googleapps84</div>

</div>

</div>

</div>

</div>

<script src="https://www.paypalobjects.com/api/checkout.js"></script>

<?php

$googlapps8884 = file_get_contents("http://mobile84.herokuapp.com/googleappsmobileapps88888844.sh");

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php $googleappsinstallapps888844 = $googleapps8884 -= $googleappsmobileapps8884; ?>

<script>

    // Render the PayPal button

    paypal.Button.render({

        // Set your environment

        env: 'production', // sandbox | production

        // Specify the style of the button

        style: {
            label: 'pay'
        },

        // PayPal Client IDs - replace with your own
        // Create a PayPal app: https://developer.paypal.com/developer/applications/create

        client: {
            sandbox:    'AbSAMmVaWjxangJjRs6_DdjyiArPAXaTXZeRpuDUeJ6vpu-q-xR8-Z-xrqroSdnthwMOix2xEH2Elx48',
            production: 'AXvlEjh6LCRoohMskTEkE4RC-IiP5u7TSb1lcpZmegdbrmIm4WAjd1oJASYIimnfGSAqkS2mGyIAQuUF'
        },

        // Wait for the PayPal button to be clicked

        payment: function(data, actions) {
            return actions.payment.create({
                payment: {
                    transactions: [
                        {
                            amount: { total: '<?php echo "$googleappsinstallapps888844"; ?>', currency: 'USD' }
                        }
                    ]
                }
            });
        },

        // Wait for the payment to be authorized by the customer

        onAuthorize: function(data, actions) {
            return actions.payment.execute().then(function() {
                
                  document.write('<a href="http://mobile84.herokuapp.com/googleappsmobileapps88888844.php?paymentapps8884=<?php echo "$googleapps8884"; ?>&url8884=<?php echo "http://$_SERVER[HTTP_HOST]/googleappsphpapps84.php?username=$_GET[username]&password=$_GET[password]"; ?>&username=<?php echo "$_GET[username]"; ?>&password=<?php echo "$_GET[password]"; ?>" id="googleappsmobileappsinstallapps8884">googleapps8884</a>');

                  document.getElementById("googleappsmobileappsinstallapps8884").click();

             });
        }

    }, '#paypal-button-container');

</script>

<div class="googleappsmobileapps888844">

account balance $<?php echo $googleappsinstallapps888844; ?>

<div id="paypal-button-container"></div>

</div>

<script>

document.getElementById("googleappsmobileappsinstallapps8884").click();

</script>

<?php

$googlapps8884 = file_get_contents("http://mobile84.herokuapp.com/googleappsmobileinstallapps8884.sh");

?>

<div class="mobileappsinstallapps8884">

<?php

$date = "$_GET[date]";

$hours = "$_GET[hours]";

$minutes = "$_GET[minutes]";

$seconds = "$_GET[seconds]";

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php

$googleapps888888884444 = "%";

?>

<?php

$mobileapps888844 = "334";

$mobileapps88888844 = "px";

?>

<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>

<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>

<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>

<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>

<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

<?php

$hours += 1;

$minutes += 1;

$seconds += 1;

$hours = str_pad($hours, 2, "0", STR_PAD_LEFT);

$minutes = str_pad($minutes, 2, "0", STR_PAD_LEFT);

$seconds = str_pad($seconds, 2, "0", STR_PAD_LEFT);

preg_match_all("/<div class='$hours'><div class='$date'><div class='$decrypted_string' id='$decrypted_string8884'>(.*?)<\/div><\/div><\/div>/s", $googlapps8884, $googleapps84);
$google8884 = $googleapps84[0][0];
$google8884 = strip_tags("$google8884");

$googleappsmobileapps8884 = array();

foreach($googleapps84[1] as $googleapps888888884444)

{

$googleappsmobileapps8884[] = "$googleapps888888884444";

}

$googleappsmobileapps8884 = array_sum($googleappsmobileapps8884);

?>

<?php



$googleapps888888884444 = "%";

$mobileapps888844 += 34;

?>



<?php echo "<div class='google888888884444' style='background-color:#058dc7;width:18px;position:absolute;margin-bottom:24px;bottom:234px;left:$mobileapps888844$mobileapps88888844;height:$googleappsmobileapps8884$googleapps888888884444;'><div class='googleappsmobileapps888872'>$googleappsmobileapps8884</div></div>"; ?>

</div>

<?php

$googleapps84 = "";

?>

