<head>
<title></title>
<meta name='description' content=''>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="robots" content="index,nofollow">
<link rel="shortcut icon nofollow" href="http://mobile84.herokuapp.com/googleappslogoapps88888844.png" type="image/x-icon"/>
</head>

<style media="screen" type="text/css">

html,body
{
margin:0px;
padding:0px;
font-family: Varela Round, sans-serif;
background-color:#dddddd;
}

.googleapps84
{
position:absolute;
background-color:#ffffff;
width:100%;
box-shadow:0 0 8px 0 rgba(0,0,0,.3);
z-index:18;
}

.googleapps8884
{
padding:22px;
}

@media screen and (max-width: 960px)
{
.googleappsmobileapps8884
{
color: #444;
font-size: 28px;
font-weight: 300;
letter-spacing: -0.2px;
line-height: 38px;
padding-left: 12px!important;
}
}

</style>

<style>

.googleapps888844
{
color:#EF6C00;
}

.googleapps88888844
{
color:#F9A825;
}

.googleappsmobileapps84
{
font-size: 48px;
line-height: 58px;
position: absolute;
background-color: #f6f6f6;
width: 100%;
height: 408px;
left: 0px;
padding-top: 134px;
}

.googleappsinstallapps84
{
color: #848484;
font-size: 18px;
line-height: 27px;
width: 80%;
}

.googleappsmobileapps8884
{
padding-left:134px;
color: #444;
font-weight: 300;
letter-spacing: -0.2px;
}

.googlemobileapps8884
{
    background: #00c853;
    border: none;
    border-radius: 2px;
    color: #fff;
    display: inline-block;
    font-family: 'Roboto',arial,sans-serif;
    font-size: 16px;
    height: 48px;
    letter-spacing: .5px;
    line-height: 48px;
    padding: 0 24px;
    text-decoration: none;
    text-transform: uppercase;
    white-space: nowrap;
}

</style>

<div class="googleapps84">
<div class="googleapps8884">

<googleapps84 class="googleapps888844">Go</googleapps84><googleapps84 class="googleapps88888844">search</googleapps84> Ads

</div>
</div>

<div class="googleappsmobileapps84">
<div class="googleappsmobileapps8884">

Reach customers

<div>

when it matters.

</div>

<div class="googleappsinstallapps84" style="padding-top:18px;">

Show your ads across Gosearch and beyond.

</div>

<div class="googlemobileapps8884" style="margin-top:18px;" onclick="window.open('<?php echo "http://$_SERVER[HTTP_HOST]/signup.php"; ?>','_self');ga('send', 'event', 'googleapps8884', 'Click','ExternalLink84');">

START NOW

</div>

</div>
</div>

