<head>
<title></title>
<meta name='description' content=''>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="robots" content="index,nofollow">
<link rel="shortcut icon nofollow" href="http://mobile84.herokuapp.com/googleappslogoapps88888844.png" type="image/x-icon"/>
</head>

<style>

html
{
}

body
{
margin:0px;
padding:0px;
}

.googleapps84
{
background-color:#dddddd;
margin:8px;
font-family: Varela Round, sans-serif;
}

.googleapps8884
{
padding:16px;
}

.input88888844
{
margin:0px;
}

.dropbtngoogleapps88888844
{
padding:12px;
font-size:16px;
font-family: Varela Round, sans-serif;
}

@media screen and (max-width: 960px)
{
.dropbtngoogleapps88888844
{
width:100%;
}
}

</style>

<div class="googleapps84">
<div class="googleapps8884">
<div class="googleapps888844">

Gosearch feedback

</div>
</div>
</div>

<div class="googleapps84">
<div class="googleapps8884">
<div class="googleapps888844">

<form action='http://mobile84.herokuapp.com/googleappsinstallapps8884.php' class="input88888844" method="get" onsubmit="return submitchat();">

<input type="text" autocomplete="off" placeholder="type your description" value="<?php echo "$installgoogleappsmobileapps84"; ?>" onkeyup="showHint(this.value)" onclick="myFunctiongoogleapps84()" class="dropbtngoogleapps88888844" name='q' id='chatbox'></input>

<input type="hidden" name="query84" value="<?php echo "$_GET[query]"; ?>"></input>

<input type="hidden" name="url888844" value="<?php echo "$_SERVER[HTTP_HOST]"; ?>"></input>

<input type="hidden" name="username" value="<?php echo "$_GET[username]"; ?>"></input>

<input type="hidden" name="secureparameter" value="<?php echo "$googleapps8888884"; ?>"></input>

<input type="hidden" name="ssl" value="<?php echo "on"; ?>"></input>

</form>

</div>
</div>
</div>

