<style>

html
{
}

body
{
margin:0px;
padding:0px;
}

.installgoogleappsapps
{
background-color: #ffffff;
font-family: Varela Round, sans-serif;
color: #222222;
border-width: 1px;
margin:8px;
border-color:#dddddd;
box-shadow:0 1px 2px rgba(0,0,0,0.4);
}

.installgoogleappsapps84
{
padding:16px;
}

h3
{
margin:0px;
}

</style>

<head>
<title></title>
<meta name='description' content=''>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="robots" content="index,nofollow">
<link rel="shortcut icon nofollow" href="http://mobile84.herokuapp.com/googleappslogoapps88888844.png" type="image/x-icon"/>
</head>

<div class="installgoogleappsapps">
<div class="installgoogleappsapps84">
<div class="installgoogleappsapps8432">

<h3>these are some search terms done on Gosearch</h3>

</div>
</div>
</div>

<?php

$googleapps84 = file_get_contents("http://mobile84.herokuapp.com/googlemobileapps8884.sh");

echo "$googleapps84";

?>

