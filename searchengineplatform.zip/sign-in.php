<style media="screen" type="text/css">

html,body
{
margin:0px;
padding:0px;
font-family: Varela Round, sans-serif;
background-color:#dddddd;
}

.googleappsmobileappsinstallapps8884
{
background-color: #ffffff;
height: 422px;
margin:0 auto;
margin-top:172px;
box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
position:absolute;
top:0px;
margin:auto;
position:absolute;
left:0;
bottom:0;
right:0;
padding:34px;
}

.input1
{
height:44px;
margin:0 auto;
width:100%;
font-size:13.8px;
padding:12px;
border-style:solid;
border-color:#dddddd;
border-top:none;
border-left:none;
border-right:none;
border-width:1px;
}

.input2
{
height:44px;
margin:0 auto;
width:100%;
font-size:18px;
padding:12px;
border-radius:4px;
border-style:solid;
border-color:#dddddd;
}

.googleapps1
{
padding:12px;
}

.googleapps2
{
padding:12px;
}

.googleappsuserapps84
{
margin-top:18px;
margin-bottom:6px;
margin-top:52px;
}

.googleappsuserappsgoogleapps84
{
margin-left:12px;
margin-bottom:6px;
}

.googleappsuserappsregisterapps84
{
font-size:34px;
padding:12px;
padding-bottom:0px;
font-size:24px;
font-weight:400;
}

.googleappsuserappsregisterappsgoogleapps84
{
padding:12px;
padding-top:0px;
color: rgba(0,0,0,.87);
direction: ltr;
font-family: 'Roboto',sans-serif;
font-size: 14px;
}

.googleappsinstallapps84
{
background-color:#4285f4;
border-style:solid;
border-width:1px;
border-radius:4px;
padding-top:8px;
padding-bottom:8px;
padding-left:18px;
padding-right:18px;
margin-left:-40px;
margin-top:34px;
color:#ffffff;
position:absolute;
-webkit-user-select: none;
-webkit-transition: background .2s .1s;
transition: background .2s .1s;
border: 0;
-webkit-border-radius: 3px;
border-radius: 3px;
cursor: pointer;
display: inline-block;
font-size: 14px;
font-weight: 500;
min-width: 4em;
outline: none;
overflow: hidden;
text-align: center;
text-transform: uppercase;
-webkit-tap-highlight-color: transparent;
z-index: 0;
bottom:18px;
right:18px;
}

@media screen and (max-width: 960px)
{
.googleappsmobileappsinstallapps8884
{
}
.googleappsmobileappsinstallapps8884
{
padding:0px;
}
.googleappsinstallapps84
{
margin-left:-108px;
}
.googleappsmobileappsinstallapps888844
{
margin:34px;
}
}

@media screen and (min-width: 960px)
{
.googleappsmobileappsinstallapps8884
{
width:362px;
}
}

@media screen and (max-width: 960px)
{
.googleappsmobileappsinstallapps8884
{
margin:16px;
}
}

.logout84
{
right:18px;
bottom:0px;
position:absolute;
padding:12px;
color:#ffffff;
}

.googleinstallapps84
{
background-color:#dddddd;
width:100%;
height:100%;
top:0px;
}

</style>

<head>
<title>signup</title>
<meta name='description' content=''>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="robots" content="index,nofollow">
<meta name="keywords" content=''>
<link rel="shortcut icon nofollow" href="http://mobile84.herokuapp.com/googleappslogoapps88888844.png" type="image/x-icon"/>
</head>

<?php

$googleapps84 = "<div>$_GET[q]</div>";

$googleapps84 = preg_replace("/\s+/","",$googleapps84);

$googleapps84 = preg_replace("/\s+/S","",$googleapps84);

$googleapps84 = preg_replace("/<div>/","",$googleapps84);

$googleapps84 = preg_replace("/<\/div>/","",$googleapps84);

$googleapps84 = preg_replace('/"/',"",$googleapps84);

?>

<div class="googleappsmobileappsinstallapps888844">

<div class="googleappsmobileappsinstallapps88884474">

<div class="googleappsmobileappsinstallapps8884">

<div class="googleappsmobileappsinstallapps8444">

<div class="googleappsuserappsregisterapps84">
Gosearch
</div>

<div class="googleappsuserappsregisterappsgoogleapps84">
sign in or register to get more relevant results
</div>

<div class="googleapps1">

<form name="input" action='<?php echo "http://$_SERVER[HTTP_HOST]/googleappsuserlogin8884.php"; ?>' method="post">

<input type="hidden" name="q" value="<?php echo "$googleapps84"; ?>"></input>

<input type="text" class="input1" placeholder="Username" value="" id="username" name="username" autocomplete="off"></input>

<input type="text" class="input1" placeholder="Password" value="" id="password" name="password" autocomplete="off" style="margin-top:16px;"></input>

</div>

<div class="googleapps2">

<div class="googleappsuserappsgoogleapps84">
</div>

<input type="submit" value="Go" name="sub" class="googleappsinstallapps84"/>

</form>

<a rel="nofollow" href="" style="color: #4285f4;text-decoration:none;margin-top:18px;margin-bottom:6px;margin-top:52px;margin-top:-18px;position:absolute;left:44px;font-size:14px;"></a>

<a rel="nofollow" href="" style="color: #4285f4;text-decoration:none;margin-top:18px;margin-bottom:6px;margin-top:52px;margin-top:34px;position:absolute;left:44px;font-size:14px;"></a>

</div>

</div>

</div>

</div>

</div>

